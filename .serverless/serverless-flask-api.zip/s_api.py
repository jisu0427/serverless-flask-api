import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jeongjisu',
    application_name='serverless-flask-api',
    app_uid='C0czy4TKsp1ccLY0rl',
    org_uid='e28f3062-6e36-4305-a120-8d6f15607ea0',
    deployment_uid='328a66da-5248-498e-89e3-b41d5e026be1',
    service_name='serverless-flask-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
