class Config :
    JWT_SECRET_KEY = 'yh@1234'